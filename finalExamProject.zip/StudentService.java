import java.util.Arrays;

public class StudentService {

    private int index = 0;
    private StudentDto[] studentDtos = new StudentDto[1];

    public void addStudent(StudentDto StudentDto) {
        studentDtos[index] = StudentDto;
        ++index;

        if(studentDtos.length == index) {
            StudentDto[] temp = studentDtos;
            studentDtos = new StudentDto[studentDtos.length + 1];
            for (int j = 0; j < temp.length; j++) {
                studentDtos[j] = temp[j];
            }
        }
    }

    public void prinAllStudents() {
        System.out.println(FontColor.ANSI_CYAN + Arrays.toString(studentDtos) + FontColor.ANSI_RESET);
        System.out.println();
    }

    public void deleteStudent(String NationalCode) {
        int index = findByNationalCode(NationalCode);
        if(index != -1) {
            StudentDto[] temp = new StudentDto[studentDtos.length-1];

            for (int i = 0; i < studentDtos.length; i++) {
                if(studentDtos[i] != null && i != index) {
                    temp[i] = studentDtos[i];
                }
            }
            studentDtos = temp;
            this.index--;

        } else {
            System.out.println(FontColor.ANSI_RED + "Student not found!!" + FontColor.ANSI_RESET);
        }
    }

    public void findStudent(String NationalCode) {
        int index = findByNationalCode(NationalCode);
        if(index != -1) {
            System.out.println(FontColor.ANSI_CYAN + studentDtos[index] + FontColor.ANSI_RESET);
        } else {
            System.out.println(FontColor.ANSI_RED + "student not found!!" + FontColor.ANSI_RESET);
        }
    }

    public int findByNationalCode(String NationalCode) {

        int index = -1;

        for (int i = 0; i < studentDtos.length; i++) {
            if(studentDtos[i] != null && studentDtos[i].getNathionalCode().equals(NationalCode)) {
                index = i;
            }
        }

        return index;
    }


}
