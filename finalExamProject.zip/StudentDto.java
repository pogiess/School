public class StudentDto {

    //data
    private final String fullName;
    private final String fatherName;
    private final String nathionalCode;
    private final String birthday;

    //structures
    public StudentDto(String birthday , String nathionalCode , String fatherName , String fullName) {
        this.fullName = fullName;
        this.fatherName = fatherName;
        this.nathionalCode = nathionalCode;
        this.birthday = birthday;
    }


    //getter and setter methods
    public String getFullName() {
        return fullName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public String getNathionalCode() {
        return nathionalCode;
    }

    public String getBirthday() {
        return birthday;
    }

    public String toString() {
        return "StudentDto( " +
                " \'full name : " + fullName + "\' | " +
                " \'father name : " + fatherName + "\' | " +
                " \'nathional code : " + nathionalCode + "\' | " +
                " \'birthday : " + birthday +
                "\' )";
    }
}
