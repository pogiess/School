public class LessonDto {

    private final String name;
    private final String title;
    private final String description;
    private final int units;

    public LessonDto(String name , String title , String description , int units) {
        this.name = name;
        this.title = title;
        this.description = description;
        this.units = units;
    }


    public String getName() { return name; }
    public String getTitle() {
        return title;
    }
    public String getDescription() {
        return description;
    }
    public int getUnits() {
        return units;
    }

    public String toString() {
        return "LessonDto( " +
                " \'name : " + name + "\' | " +
                " \'title : " + title + "\' | " +
                " \'description : " + description + "\' | " +
                " \'units : " + units +
                "\' )";
    }

}
