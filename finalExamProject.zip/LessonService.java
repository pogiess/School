import java.util.Arrays;

public class LessonService {

    private LessonDto[] lessonDtos = new LessonDto[1];

    private int index = 0;

    public void addLesson(LessonDto LessonDto) {
        lessonDtos[index] = LessonDto;
        index++;

        if(lessonDtos.length == index) {
            LessonDto[] temp = lessonDtos;
            lessonDtos = new LessonDto[lessonDtos.length + 1];
            for (int i = 0; i < temp.length; i++) {
                lessonDtos[i] = temp[i];
            }
        }
    }

    public void findLesson(String name) {
        int index = findLessonByName(name);

        if(index != -1) {
            System.out.println(FontColor.ANSI_CYAN + lessonDtos[index] + FontColor.ANSI_RESET);
        } else {
            System.out.println(FontColor.ANSI_RED + "Lesson not found!!" + FontColor.ANSI_RESET);
        }
    }

    public int findLessonByName(String name) {
        int index = -1;

        for (int i = 0; i < lessonDtos.length; i++) {
            if(lessonDtos[i] != null && lessonDtos[i].getName().equals(name)) {
                index = i;
            }
        }

        return index;
    }

    public void deleteLesson(String name) {
        int index = findLessonByName(name);

        if(index != -1) {
            LessonDto[] temp = new LessonDto[lessonDtos.length-1];
            for (int i = 0; i < lessonDtos.length; i++) {
                if(lessonDtos[i] != null && index != i) {
                    temp[i] = lessonDtos[i];
                }
            }
            lessonDtos = temp;
            this.index--;
        } else {
            System.out.println(FontColor.ANSI_RED + "Lesson not found!!" + FontColor.ANSI_RESET);
        }
    }

    public void printLesson() {
        System.out.println(FontColor.ANSI_CYAN + Arrays.toString(lessonDtos) + FontColor.ANSI_RESET);
        System.out.println();
    }

}
