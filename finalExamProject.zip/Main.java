import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {

        Scanner scs = new Scanner(System.in);

        StudentService sService = new StudentService();
        TeacherService tService = new TeacherService();
        LessonService lService = new LessonService();


        boolean continueWorkingWithObjects = true;


        //what to do with main menu and objects
        while(true) {
            printMainMenu(); //showing main menu
            switch(getNumber()) {
                case 1:

                    boolean untilStudent = true;
                    while(untilStudent) {
                        printStudentMenu();
                        switch (getNumber()) {
                            case 1 -> {
                                sService.addStudent(getStudent());
                                break;
                            }
                            case 2 -> {
                                sService.findStudent(getNationalCode());
                                break;
                            }
                            case 3 -> {
                                sService.deleteStudent(getNationalCode());
                                break;
                            }
                            case 4 -> {
                                sService.prinAllStudents();
                                break;
                            }
                            case 5 -> {
                                untilStudent = false;
                                break;
                            }
                            default -> System.out.println("invalid input!!");
                        }
                    }
                    break;
                case 2:
                    boolean untilTeacher = true;
                    while(untilTeacher) {
                        printTeacherMenu();
                        switch (getNumber()) {
                            case 1 -> {
                                tService.addTeacher(getTeacher());
                            }
                            case 2 -> {
                                tService.findTeacher(getNationalCode());
                            }
                            case 3 -> {
                                tService.deleteTeacher(getNationalCode());
                            }
                            case 4 -> {
                                tService.printAllTeachers();
                            }
                            case 5 -> {
                                untilTeacher = false;
                                break;
                            }
                            default -> System.out.println("invalid input!!");
                        }
                    }
                    break;
                case 3:
                    boolean untilLesson = true;
                    while(untilLesson) {
                        printLessonMenu();
                        switch (getNumber()) {
                            case 1 -> {
                                lService.addLesson(getLesson());
                            }
                            case 2 -> {
                                lService.findLesson(getName());
                            }
                            case 3 -> {
                                lService.deleteLesson(getName());
                            }
                            case 4 -> {
                                lService.printLesson();
                            }
                            case 5 -> {
                                untilLesson = false;
                                break;
                            }
                            default -> System.out.println("invalid input!!");
                        }
                    }
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("invalid input!!");
            }

        }

    }

    public static void printMainMenu() {
        System.out.println(FontColor.ANSI_BLUE + "\n_______________________________________MainMenu**");
        System.out.println("1- Student Menu");
        System.out.println("2- Teacher Menu");
        System.out.println("3- Lesson Menu");
        System.out.println("4- Exit");
        System.out.println("_________________________________________" + FontColor.ANSI_RESET);
    }

    public static void printStudentMenu() {
        System.out.println(FontColor.ANSI_PURPLE + "\n_______________________________________StudentMenu**");
        System.out.println("1- add student");
        System.out.println("2- find Student");
        System.out.println("3- delete Student");
        System.out.println("4- print all Students");
        System.out.println("5- return to main Menu");
        System.out.println("_________________________________________" + FontColor.ANSI_RESET);
    }

    public static void printTeacherMenu() {
        System.out.println(FontColor.ANSI_PURPLE + "\n_______________________________________TeacherMenu**");
        System.out.println("1- add Teacher");
        System.out.println("2- find Teacher");
        System.out.println("3- delete Teacher");
        System.out.println("4- print all Teacher");
        System.out.println("5- return to main Menu");
        System.out.println("_________________________________________" + FontColor.ANSI_RESET);
    }

    public static void printLessonMenu() {
        System.out.println(FontColor.ANSI_PURPLE + "\n_______________________________________LessonMenu**");
        System.out.println("1- add Lesson");
        System.out.println("2- find Lesson");
        System.out.println("3- delete Lesson");
        System.out.println("4- print all Lesson");
        System.out.println("5- return to main Menu");
        System.out.println("_________________________________________" + FontColor.ANSI_RESET);
    }

    public static String getName() {
        Scanner scs = new Scanner(System.in);
        System.out.print(FontColor.ANSI_GREEN + "enter name of lesson : " + FontColor.ANSI_RESET);
        return scs.nextLine();
    }

    public static int getNumber() {
        Scanner scs = new Scanner(System.in);
        System.out.print(FontColor.ANSI_GREEN + "what to do with menu : " + FontColor.ANSI_RESET);
        return scs.nextInt();
    }

    public static String getNationalCode() {
        Scanner scs = new Scanner(System.in);
        System.out.print(FontColor.ANSI_GREEN + "please enter your National code : " + FontColor.ANSI_RESET);
        return scs.nextLine();
    }

    public static StudentDto getStudent() {
        Scanner scs = new Scanner(System.in);

        String fullName = null;
        String fatherName = null;
        String birthday = null;

        System.out.print(FontColor.ANSI_GREEN + "please enter full name : " + FontColor.ANSI_RESET);
        fullName = scs.nextLine();

        System.out.print(FontColor.ANSI_GREEN + "please enter father name : " + FontColor.ANSI_RESET);
        fatherName = scs.nextLine();

        System.out.print(FontColor.ANSI_GREEN + "please enter you birthday : " + FontColor.ANSI_RESET);
        birthday = scs.nextLine();


        return new StudentDto(birthday , getNationalCode() , fatherName , fullName);
    }

    public static TeacherDto getTeacher() {
        Scanner scs = new Scanner(System.in);

        String fullName = null;
        String birthday = null;
        int age = 0;

        System.out.print(FontColor.ANSI_GREEN + "please enter full name : " + FontColor.ANSI_RESET);
        fullName = scs.nextLine();

        System.out.print(FontColor.ANSI_GREEN + "please enter you birthday : " + FontColor.ANSI_RESET);
        birthday = scs.nextLine();

        System.out.print(FontColor.ANSI_GREEN + "please enter age : " + FontColor.ANSI_RESET);
        age = scs.nextInt();



        return new TeacherDto(fullName , getNationalCode() , birthday , age);
    }

    public static LessonDto getLesson() {
        Scanner scs = new Scanner(System.in);

        String name = null;
        String title = null;
        String description = null;
        int units = 0;

        name = getName();

        System.out.println(FontColor.ANSI_GREEN + "enter title" + FontColor.ANSI_RESET);
        title = scs.nextLine();

        System.out.println(FontColor.ANSI_GREEN + "enter description : " + FontColor.ANSI_RESET);
        description = scs.nextLine();

        System.out.println(FontColor.ANSI_GREEN + "enter units : " + FontColor.ANSI_RESET);
        units = scs.nextInt();

        return new LessonDto(name , title , description , units);
    }

}