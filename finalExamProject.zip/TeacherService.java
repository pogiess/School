import java.util.Arrays;

public class TeacherService {

    private TeacherDto[] teacherDtos = new TeacherDto[1];
    private int index = 0;

    public void addTeacher(TeacherDto TeacherDto) {
        teacherDtos[index] = TeacherDto;
        ++index;

        if(teacherDtos.length == index) {
            TeacherDto[] temp = teacherDtos;
            teacherDtos = new TeacherDto[teacherDtos.length + 1];
            for (int i = 0; i < temp.length; i++) {
                teacherDtos[i] = temp[i];
            }
        }
    }

    public void deleteTeacher(String nationalCode) {
        int index = findByNationalCode(nationalCode);
        TeacherDto[] temp = new TeacherDto[teacherDtos.length-1];

        if(index != -1) {

            for (int i = 0; i < teacherDtos.length; i++) {
                if(teacherDtos[i] != null && index != i) {
                    temp[i] = teacherDtos[i];
                }
            }
            teacherDtos = temp;
            this.index--;
        } else {
            System.out.println(FontColor.ANSI_RED + "Teacher not found!!" + FontColor.ANSI_RESET);
        }

    }

    public void findTeacher(String nationalCode) {
        int index = findByNationalCode(nationalCode);

        if(index != -1) {
            System.out.println(FontColor.ANSI_CYAN + teacherDtos[index] + FontColor.ANSI_RESET);
        } else {
            System.out.println(FontColor.ANSI_RED + "Teacher not found!!" + FontColor.ANSI_RESET);
        }
    }

    public int findByNationalCode(String nationalCode) {
        int index = -1;

        for (int i = 0; i < teacherDtos.length; i++) {
            if(teacherDtos[i] != null && teacherDtos[i].getNathionalCode().equals(nationalCode)) {
                index = i;
            }
        }

        return index;
    }

    public void printAllTeachers() {
        System.out.println(FontColor.ANSI_CYAN + Arrays.toString(teacherDtos) + FontColor.ANSI_RESET);
        System.out.println();
    }

}
