public class TeacherDto {

    private final String nathionalCode;
    private final String fullName;
    private final int age;
    private final String birthday;


    public TeacherDto(String fullName , String nathionalCode , String birthday , int age) {
        this.fullName = fullName;
        this.nathionalCode = nathionalCode;
        this.birthday = birthday;
        this.age = age;
    }

    public String getFullName() {
        return fullName;
    }


    public String getNathionalCode() {
        return nathionalCode;
    }


    public int getAge() {
        return age;
    }


    public String getBirthday() {
        return birthday;
    }

    public String toString() {
        return "TeacherDto( " +
                " \'full name : " + fullName + "\' | " +
                " \'Age : " + age + "\' | " +
                " \'nathional code : " + nathionalCode + "\' | " +
                " \'birthday : " + birthday +
                "\' )";
    }

}
